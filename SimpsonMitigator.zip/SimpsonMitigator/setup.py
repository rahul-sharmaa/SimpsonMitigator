from setuptools import setup, find_packages

setup(
    name='simpson-mitigator',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'numpy>=1.21.0',
        'pandas>=1.3.0',
        'scikit-learn>=1.0.0',
        'scipy>=1.7.0'
    ],
    author='Rahul Sharma',
    author_email='rahul.sharma@taltech.ee',
    description='A Python package to detect and mitigate Simpson’s paradox in machine learning workflows.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/rahul-sharmaa/SimpsonP',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)