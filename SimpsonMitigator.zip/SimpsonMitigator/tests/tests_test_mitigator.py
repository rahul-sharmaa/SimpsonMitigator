import pytest
import pandas as pd
from simpson_mitigator import SimpsonMitigator
from sklearn.ensemble import RandomForestClassifier

@pytest.fixture
def sample_data():
    data = pd.DataFrame({
        'gender': ['M', 'F', 'M', 'F', 'M', 'F'],
        'department': ['A', 'A', 'B', 'B', 'A', 'B'],
        'admitted': [1, 0, 0, 1, 1, 0],
        'score': [80, 75, 65, 70, 85, 60]
    })
    data['gender'] = data['gender'].astype('category')
    data['department'] = data['department'].astype('category')
    return data

def test_detect_confounders(sample_data):
    mitigator = SimpsonMitigator()
    confounders = mitigator.detect_confounders(sample_data, 'gender', 'admitted', categorical=True)
    assert isinstance(confounders, list)
    assert all(isinstance(c, tuple) and len(c) == 2 for c in confounders)

def test_adjust_confounders(sample_data):
    mitigator = SimpsonMitigator()
    confounders = mitigator.detect_confounders(sample_data, 'gender', 'admitted', categorical=True)
    conf_cols = [c[0] for c in confounders]
    adjusted_data = mitigator.adjust_confounders(sample_data, 'gender', 'admitted', conf_cols)
    assert 'weighted_admitted' in adjusted_data.columns
    assert adjusted_data.shape[0] == sample_data.shape[0]

def test_evaluate(sample_data):
    mitigator = SimpsonMitigator()
    model = RandomForestClassifier()
    metrics = mitigator.evaluate(sample_data, model, ['score', 'admitted'], 'admitted', 'gender')
    assert all(key in metrics for key in ['accuracy', 'DPD', 'EOD'])
    assert 0 <= metrics['accuracy'] <= 1
    assert 0 <= metrics['DPD'] <= 1
    assert 0 <= metrics['EOD'] <= 1